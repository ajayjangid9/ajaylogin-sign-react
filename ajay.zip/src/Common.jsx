import React from "react";
const Common = ({data}) =>{
    return(
        <>
        <h1>{data}</h1>
        </>
    )
}
export default Common;