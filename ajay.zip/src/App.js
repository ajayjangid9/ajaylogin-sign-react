import logo from './logo.svg';
import Common from "./Common";
import First from "./First.js";
import './index.css';
import { useState } from 'react';

function App() {
  const [data ,setData] = useState();

const getshow = (e) =>{
 console.log(e);
 setData(e)
}

  return (
    <div className="App">
      <First getshow={getshow}/>
      <Common data={data}/>
   
    </div>
  );
}

export default App;
