import React from "react";



const First = ({getshow}) =>{

    const name =" index file";
    return (    
        <>
       <button onClick={()=>{
           getshow(name)
       }}>send</button>
        </>
    )
}
export default First;