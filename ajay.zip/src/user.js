import React from "react";


const User = () =>{

    return(
      <>
      <h1>wfetgtes</h1>
   
      </>
    );
    
}

export default User;