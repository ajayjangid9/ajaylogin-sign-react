import React from "react";

import Common from "./Common";

const Index = () =>{
    return (    
   <Common first="hello ajay"/>
    )
}
export default Index;