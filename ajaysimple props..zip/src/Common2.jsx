import React from "react";

const Common2 = (prop) =>{
    return(
        <>
        <h1>{prop.second}</h1>
        </>
    )
}
export default Common2;