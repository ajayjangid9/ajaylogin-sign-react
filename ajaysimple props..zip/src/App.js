import logo from './logo.svg';
import Common from "./Common";
import Common2 from "./Common2";

import './index.css';

function App() {
  return (
    <div className="App">
      <Common  first=""/>
      <Common2 second="mr ajay"/>
    </div>
 
  );
}


export default App;
