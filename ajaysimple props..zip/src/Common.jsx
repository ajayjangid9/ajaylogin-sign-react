import React from "react";

const Common = (prop) =>{
    return(
        <>
        <h1>{prop.first}</h1>
        </>
    )
}
export default Common;